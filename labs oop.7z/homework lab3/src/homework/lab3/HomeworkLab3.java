/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework.lab3;

import java.util.Scanner;

/**
 *
 * @author Your Pc
 */
public class HomeworkLab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //System.out.println("hello");
        
        //create class scanner for 3 numbers
        System.out.println("=============================");
        System.out.println("Enter the frist number: ");
        Scanner input= new Scanner(System.in);
        int num1 =input.nextInt();
        System.out.println("the frist number is: "+num1+".");
//        System.out.println("=============================");
//        
//        System.out.println("Enter the Seconed number: ");
//        int num2 =input.nextInt();
//        System.out.println("the frist number is: "+num2+".");
//        System.out.println("=============================");
//        
//        System.out.println("Enter the third number: ");
//        int num3 =input.nextInt();
//        System.out.println("the frist number is: "+num3+".");
//        System.out.println("=============================");
//        //check laergest number
//        int largest = num1;
//        if (num2 > largest){
//            largest=num2;
//        }
//        if (num3 > largest){ 
//            largest = num3;
//        }
//        System.out.println("The largest number is: " + largest+".");
//        System.out.println("=============================");
//        
//        //exercise2: check from numbers even or odd
//        // choose num1 
//        if(num1%2==0)
//            System.out.println("Number "+num1+" is even.");
//        else
//            System.out.println("Number "+num1+" is odd.");
//        
//        //exercise3 check strong earthquake
//        System.out.println("Enter value earthquake measured: ");
//        int value = input.nextInt();
//        String effect;
//        if (value >= 8)
//            effect="Most Structure fall.";
//        else if (value >=7 )
//            effect="Many buildings destroyed";
//        else if (value >= 6)
//            effect="Many buildings considerably damaged, some coolapes.";
//        else if (value>=4)
//            effect="Damage to poorly.";
//        else
//            effect="Nothing.";
//        System.out.println("The effect of the earthquake is: " + effect);
//       
        System.out.println("=============================");
        System.out.print("Enter the testcase: ");
        int testcase = input.nextInt();
        
        // Consume the newline character left in the buffer
        input.nextLine();
        System.out.print("Are you married? (yes/no): ");
        String status = input.nextLine();
        
        double tax = 0.0;
        // married yes 
        if (testcase <= 64000 && status.equals("yes")) {
            tax = testcase * 0.1; // 10% tax
            System.out.println("Tax amount: " + tax);
            System.out.println("status: Married ");
        } 
        //
        else if (testcase >= 64000 && status.equals("yes")) {
            int base = 64000;
            int remaining = testcase - base;
            tax = base * 0.1 + remaining * 0.25; // 10% for the first 32000, 25% for the remaining
            System.out.println("Tax amount: " + tax);
            System.out.println("status: Married ");
        }
        
        //single
        else if (testcase >= 32000 && status.equals("no")) {
  
            int base = 32000;
            int remaining = testcase - base;
            tax = base * 0.1 + remaining * 0.25; // 10% for the first 32000, 25% for the remaining
            System.out.println("Tax amount: " + tax);
            System.out.println("status: Single ");
        }
        
        
        
        // single
        else if (testcase <= 32000 && status.equals("no")) {
            tax = testcase * 0.1; // 10% tax
            System.out.println("Tax amount: " + tax);
            System.out.println("status: Single");
        }
        else{
            System.out.println("Tax amount: " + tax);
        }
        //Q2: prints the number of days in the month
        
        System.out.println("Enter the number: ");
        int numday = input.nextInt();
        if (numday >= 1 && numday <=12){
            if (numday ==2)
                System.out.println("February has 28 days.");
            //int result = numday * 6 ;
            else
                System.out.println(numday * 6+" days");
        }
        else
            System.out.println("Value is error.");
        
        // Q3: write programe positive or nagative
        String output = (num1 > 0)? "Positive":"Nagative";
        System.out.println(output);
        
    }
        
}
