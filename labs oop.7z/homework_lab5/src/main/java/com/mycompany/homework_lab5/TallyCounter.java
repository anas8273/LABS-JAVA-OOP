/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homework_lab5;

//Q2)
//public class TallyCounter {
//    private int count;
//    private int undoCount; // To keep track of undo operations
//
//    public TallyCounter() {
//        count = 0;
//        undoCount = 0;
//    }
//
//    public void increment() {
//        count++;
//        undoCount = 0; // Reset undoCount when a regular click occurs
//    }
//
//    public void undo() {
//        // Allow undo only if the counter was clicked at least once and undo is not used more than clicks
//        if (count > 0 && undoCount < count) {
//            count--;
//            undoCount++;
//        }
//    }
//
//    public void reset() {
//        count = 0;
//        undoCount = 0;
//    }
//
//    public int getCount() {
//        return count;
//    }
//}

public class TallyCounter {
    private int count;
    private int limit;

    public TallyCounter() {
        count = 0;
        limit = Integer.MAX_VALUE; // بدون حد أولي ;
    }

    public void increment() {
        if(count < limit)
            count++;
    }

    public void reset() {
        count = 0;
    }
    
    // زر التراجع بحيث يضمن انه ماراح ينقص من   0
    public void undo() {
        count = Math.max(count -1,0);
    }
    
    public void setlimit(int maximum){
        limit = Math.max(maximum,0);
        if(count > limit)
            count = limit;
    }
    public int getCount() {
        return count;
    }
}
