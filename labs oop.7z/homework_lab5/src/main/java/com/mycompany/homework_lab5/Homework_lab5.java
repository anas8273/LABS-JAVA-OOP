/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.homework_lab5;

import java.util.Scanner;

/**
 *
 * @author Your Pc
 */
public class Homework_lab5 {

    public static void main(String[] args) {
        // lab 5 exercies
        //Design and implement a class that models a tally counter
        System.out.println("class that models a tally counter:");
        TallyCounter counter = new TallyCounter();
        counter.increment(); // Increment count by 1
        counter.increment(); // Increment count by 1
        counter.increment(); // Increment count by 1

        System.out.println("Current count: " + counter.getCount()); // Output: 3

        counter.reset(); // Reset count to 0

        System.out.println("Current count after reset: " + counter.getCount()); // Output: 0
        System.out.println("=========================================================");
        
        //input from user
        System.out.println("Enter Student's name: ");
        Scanner input = new Scanner(System.in);
        String name= input.nextLine(); 
        
        System.out.println("Enter Id: ");
        int id = input.nextInt();
        
        System.out.println("Enter Age: ");
        int age = input.nextInt();
        
        System.out.println("Enter Major: ");
        String major = input.next();
        System.out.println("===============================");
        //homework lab 5
        //Q1)
        //Students Class
        Student s1 = new Student(id,name,age,major);
        System.out.println(s1.toString());
        
        Student s2 = new Student(id,name,age,major);
        
        System.out.println("Enter new Student's name: ");
        String name_update =input.next();
        
        s2.setName(name_update);
        System.out.println(s2.getName());
        
        System.out.println("===============================");
        
        //BancAccount
        BankAccount account = new BankAccount();
        account.deposit(1000);
        account.withdraw(500);
        account.withdraw(400);
        account.deposit(3000);
        account.deposit(5000);
        account.withdraw(1000);

        // Print initial balance
        System.out.println("Initial balance: $" + account.getBalance());

        // Deduct monthly fee
        account.deductMonthlyFee();

        // Print balance after fee deduction
        System.out.println("Balance after fee deduction: $" + account.getBalance());
    }
}
