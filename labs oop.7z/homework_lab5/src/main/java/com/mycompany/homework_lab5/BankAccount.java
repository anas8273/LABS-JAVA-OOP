/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homework_lab5;

public class BankAccount {
    private double blance;
    private int transactionCount;
    private static final double TRANSACTION_FEE = 1.0;
    private static final int FREE_TRANSACTIONS = 5;
    
    public BankAccount(){
        blance = 0;
        transactionCount = 0;
    }
    
    public void deposit(double amount){
        blance+=amount;
        transactionCount++;
    }
    
    public void withdraw(double amount){
        if(amount <= blance){
            blance-=amount;
            transactionCount++;}
        else
         System.out.println("Insufficient balance.");    
    }
    
    public void deductMonthlyFee() {
        if (transactionCount > FREE_TRANSACTIONS){
            double totalFea =(transactionCount-FREE_TRANSACTIONS)* TRANSACTION_FEE;
            blance-=totalFea;
        }
        transactionCount = 0; //next month
        
    }
    public double getBalance(){
        return blance;
    }
    
}
