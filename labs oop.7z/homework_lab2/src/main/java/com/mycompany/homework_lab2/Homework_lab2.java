/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.homework_lab2;

import java.util.Scanner;


public class Homework_lab2 {

    public static void main(String[] args) {
//        Employee e = new Employee(20299,7476.585885,"Ahmed");
//        e.printDetails();
//        
        // Scanner input from user
        Scanner i = new Scanner(System.in);
//        System.out.println("Enter your name: ");
//        String name = i.nextLine();
//        System.out.println("Enter Id: ");
//        int id = i.nextInt();
//        System.out.println("Enter Salary: ");
//        double salary = i.nextDouble();
//        
//        // Create another object use values from user
//        Employee e1 = new Employee(id,salary,name);
//        e1.printDetails();

        
        //homework
        //Q1) Write a Java program to read and print the area and perimeter of a circle
        // perimeter = 2 * pi *R , area = R*R * pi
        System.out.println("Enter the radius of the circle:"); // R is Redius
        int R = i.nextInt();
        double area = Math.PI * R * R;
        double perimeter = (int) (2 * Math.PI * R);
        System.out.println("Area of circle = "+area);
        System.out.println("Perimeter of the circle= "+perimeter);
        System.out.println("=========================================");
        
        //Q2) Write a Java program to swap two variables ?
        String str = "Anas Majed";
        System.out.println(str.replace(str, "Ahmed"));
        System.out.println(str.replace("Anas", "Ahmed"));
        System.out.println("=========================================");
        
        // Q3) Write a Java program to compute a specified formula .
        double result = (11.0 / 1.0) - (9.0 / 1.0) + (7.0 / 1.0) - (5.0 / 1.0) + (3.0 / 1.0) - 1.0 * 4.0;
        System.out.println("Result: " + result);
        System.out.println("=========================================");
        
        //Q4)How do you get the first character of a string? The last character?
        String text = "Hello";
        char firstChar = text.charAt(0);
        int length = text.length()-1 ;
        System.out.println("First character: " + firstChar); // Output: H
        System.out.println("Last character: " + text.charAt(length));
        System.out.println("Without first character:  " + text.substring(0));
        System.out.println("Without last character: " + text.substring(length));
        System.out.println("=========================================");
        
        //Q5) What are the values of the following expressions?
        String ss = "Hello";
        String tt = "WORLD";
        System.out.println(ss.length()+tt.length());
        System.out.println("=========================================");
        
        //System.out.printf("This word %s substring(2,1: )",(ss)+ss.substring(2, 1)); Error
        System.out.println(ss.substring(ss.length() / 2, ss.length())) ;
        System.out.println(ss+", "+tt);
        System.out.println(tt+", "+ss);
        System.out.println("=========================================");
        
        // Q6) Write the miximum number between two numbers
        System.out.println("Enter the first number:"); 
        int nn = i.nextInt();
        System.out.println("Enter the first number:"); 
        int nn2 = i.nextInt();
        System.out.println("");
        int max = Math.max(nn,nn2);
        System.out.println("The maximum number is: " + max);
        System.out.println("=========================================");
        
        // Q7)Write a program that reads a number and displays the square, cube
        System.out.println("Square: "+nn *nn2);
        System.out.println("Cube: "+Math.pow(nn, 3));
        System.out.println("Fourth: "+Math.pow(nn, 4));

        
        // Write a java program that read two integer numbers , and make all 
         //Arithmetic operations ( summation , subtraction , multiplication , division )
//         System.out.println("Enter the first number: ");
//         int  n1 = i.nextInt();
//         System.out.println("Enter the Second number: ");
//         int n2 = i.nextInt();
//         System.out.println("Enter the operator (+, -, *, /): ");
//         char o = i.next().charAt(0);
//         int result = 0;
//         //condition
//         switch(o){
//             case '+':
//                 result = n1+n2;
//                 break;
//                 
//             case '-':
//                result = n1 - n2;
//                break;
//            case '*':
//                result = n1 * n2;
//                break;
//            case '/':
//                if (n2 != 0) {
//                    result = n1 / n2;
//                } else {
//                    System.out.println("Cannot divide by zero.");
//                    return;
//                }
//                break;
//            default:
//                System.out.println("Invalid operator.");
//                return;
//         }
//         System.out.println("Result: " + result);
//         
//         //Q5
//        // Declare and initialize two String variables
//        String str1 ="Hello, World";
//        String str2 = "hello, world";

        // Check if the two strings are equal using equals() method
//        System.out.println("Are the String equals? "+str1.equals(str2));
//        // Use charAt() method to get a character at a specific index
//        System.out.println("Character at index 7: "+str1.charAt(7));
//        System.out.printf("Uppercase(%s): ",(str2)+": "+str2.toUpperCase());
//        System.out.println();
//        System.out.printf("lowercase (%s): ",(str1)+": "+str1.toLowerCase());
//        System.out.println();
         
    }
}



    

         
