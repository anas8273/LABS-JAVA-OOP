/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homework_lab2;

/**
 *
 * @author Your Pc
 */
public class Employee {
    int id;
    double salary;
    String name;
    
    // constructor
    public Employee(int id,double salary,String name){
        this.id = id;
        this.name = name;
        this.salary = salary;  
    }
    
    // Method to print the variables in printf() method
    public void printDetails() {
        System.out.printf("Employee id : %d, name : %s, salary : %.2f%n",id,name,salary);
    }
    
}


