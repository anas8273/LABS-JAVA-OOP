/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.homework_lab1;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class Homework_lab1 {

    public static void main(String[] args) {
        //Q4)
        System.out.println("=======================");
        String name1= JOptionPane.showInputDialog("Enter your name:");
        String message = "Hello, " + name1+ "!";
        JOptionPane.showMessageDialog(null, message);
        
        
        //Q2
//        Scanner scanner = new Scanner(System.in);
//        
//        System.out.print("Enter your name: ");
//        String name = scanner.nextLine();
//          int nameLength = name.length();


        //length name1
        int nameLength = name1.length();
        
        // Print top border
        System.out.print("+");
        for (int i = 0; i < nameLength + 2; i++) {
            System.out.print("-");
        }
        System.out.println("+");
        
        // Print sides with name
        System.out.println("| " + name1+ " |");
        
        // Print bottom border
        System.out.print("+");
        for (int i = 0; i < nameLength + 2; i++) {
            System.out.print("-");
        }
        System.out.println("+");
        
        //Q3) Write a program java 
        System.out.println((55+9) % 9);
        System.out.println(-5 + 8 *6);
        System.out.println(20 + -3*5 / 8);
        System.out.println(5 + 15 / 3 * 2 - 8 % 3);
        
        System.out.println("=======================");
        
        //Q1)Write a program that prints the sum of the first ten positive 
        int sum = 0;
        for(int i=1; i <=10; i++){
            if(i%2==0){
                sum+=i;
            }
        }
        System.out.println("Sum Numbers of positive = "+sum);
        
        // First way
        System.out.println("=======================");
        System.out.println("   +");
        System.out.println("  + +");
        System.out.println(" +   +");
        System.out.println("+-----+");
        System.out.println("|. - .|");
        System.out.println("| | | |");
        System.out.println("+-+-+-+");
        
        
        // Seconed Way
        System.out.println("=======================");
        int size = 3; // تعديل حسب حجم الرسم المطلوب
        
        // طباعة الأجزاء العلوية من البيت
        for (int i = 1; i <= size; i++) {
            for (int j = i; j < size; j++) {
                System.out.print(" ");
            }
            System.out.print("+");
            
            if (i > 1) {
                for (int j = 1; j < i * 2 - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("+");
            }
            
            System.out.println();
        }
        
        // طباعة الجدران الوسطى
        System.out.println("+-----+");
        for (int i = 1; i <= size - 2; i++) {
            System.out.println("|. - .|");
        }
        
        // طباعة الأرضية
        System.out.println("+-+-+-+");
    }
}







        
 
